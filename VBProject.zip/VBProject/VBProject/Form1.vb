﻿Imports System.Configuration
Imports System.IO

Public Class Form1

    Dim errorMessage As String
    Dim FileName As String
    Dim ShowDel As String
    Dim dblclToDel As String
    Dim caseSensitive As String

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Label1.Text = ConfigurationManager.AppSettings("LabelText")
        Me.Text = ConfigurationManager.AppSettings("FormTitle")
        Button1.Text = ConfigurationManager.AppSettings("ButtonText")
        errorMessage = ConfigurationManager.AppSettings("ErrorMessage")
        FileName = Directory.GetCurrentDirectory() + "\data.d"
        ShowDel = ConfigurationManager.AppSettings("showDeleteButton")
        caseSensitive = ConfigurationManager.AppSettings("CheckCaseSensitive")
        Dim showData As String = ConfigurationManager.AppSettings("showData")
        Dim delOnStart As String = ConfigurationManager.AppSettings("DeleteEntriesOnStart")
        dblclToDel = ConfigurationManager.AppSettings("AllowSingleDelete")
        If ShowDel.ToLower().Equals("true") Then
            Button2.Visible = True
        Else
            Button2.Visible = False
        End If
        If showData.ToLower().Equals("true") Then
            Me.Width = 594
        Else
            Me.Width = 342
        End If
        If delOnStart.ToLower().Equals("true") Then
            File.Delete(FileName)
        End If
        If File.Exists(FileName) Then
            ListBox1.Items.Clear()
            ListBox1.Items.AddRange(File.ReadAllLines(FileName))
        End If
        Me.AcceptButton = Button1
        TextBox1.Focus()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TextBox1.Text = "" Then
            Return
        End If
        Dim data As List(Of String)
        If File.Exists(FileName) Then
            data = File.ReadAllLines(FileName).ToList()
        Else
            data = New List(Of String)
        End If
        If Not caseSensitive.ToLower().Equals("true") Then
            If data.Contains(TextBox1.Text.Trim()) Then
                MessageBox.Show(errorMessage)
            Else
                data.Add(TextBox1.Text)
                File.WriteAllLines(FileName, data.ToArray())
            End If
        Else
            Dim dat As Boolean = ((From t In data Where t.ToLower().Equals(TextBox1.Text.ToLower().Trim())).Count() > 0)
            If dat Then
                MessageBox.Show(errorMessage)
            Else
                data.Add(TextBox1.Text)
                File.WriteAllLines(FileName, data.ToArray())
            End If
        End If

        TextBox1.Text = ""
        If File.Exists(FileName) Then
            ListBox1.Items.Clear()
            ListBox1.Items.AddRange(File.ReadAllLines(FileName))
        End If
        TextBox1.Focus()
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        File.Delete(FileName)
        If File.Exists(FileName) Then
            ListBox1.Items.Clear()
            ListBox1.Items.AddRange(File.ReadAllLines(FileName))
        Else
            ListBox1.Items.Clear()
        End If
    End Sub

    Private Sub ListBox1_KeyUp(sender As Object, e As KeyEventArgs) Handles ListBox1.KeyUp
        If dblclToDel.ToLower().Equals("true") Then
            If e.KeyCode = Keys.Delete Then
                Dim x As List(Of String) = File.ReadAllLines(FileName).ToList()
                x.Remove(ListBox1.SelectedItem.ToString())
                File.WriteAllLines(FileName, x.ToArray())
                ListBox1.Items.Remove(ListBox1.SelectedItem)
            End If
        End If
    End Sub
End Class
